#/bin/bash
#export PREFIX="$HOME/opt/cross"
#export TARGET=i686-elf
##export PATH="$PREFIX/bin:$PATH"
#make all


#/bin/bash
set -e

export PREFIX="$HOME/opt/cross"
export TARGET=i686-elf
export PATH="$PREFIX/bin:$PATH"

echo "Building peachos"
make clean
make all

echo "Build Complete"
qemu-system-i386 -drive format=raw,file=bin/os.bin -m 256M -boot d